import React, { Component } from 'react';
import arrow from '../images/arrow.png';
import axios from 'axios';
// import { read } from 'fs';



class list extends Component {
    constructor(props) {
        super(props)
        const listJson = [{"genre":["RAP","POP"],"id":"5e7fa2106926f4261b0cd0c7","artistName":"Michel","title":"SINGER","category":"MAJOR","gender":"MALE","marketValue":"100000000","stockPrice":"33.333333333333336","imgData":"","continent":"AFRICA","country":"US","city":"California","created_at":"Sun Mar 29 2020 00:44:24 GMT+0530 (India Standard Time)","v":0},{"genre":["RAP"],"_id":"5e804d206926f4261b0cd0c8","artistName":"Prasad","title":"SINGER","category":"MAJOR","gender":"FEMALE","marketValue":"100000000","stockPrice":"33.333333333333336","imgData":"","continent":"AFRICA","country":"US","city":"California","created_at":"Sun Mar 29 2020 12:54:16 GMT+0530 (India Standard Time)","_v":0}];
        this.state = {
            listItem: listJson

        }
    }
    componentDidMount() {
        // axios.get('http://jsonplaceholder.typicode.com/users')
        //     .then(res => {
        //         const listItem = res.data;
        //         this.setState({ listItem })

        //     })
        // this.setState({listItem : listJson})
    }

    render() {
        console.log(this.state.listItem)

        return (
            <div className=" mt-5">
                <ul className="list-style-none">
                    {/* <li>
                    <div className="card p-3 box-shadow">
                        <div className="border-bottom">
                            <div className="row ">
                                <div className="col-md-2"></div>
                                <div className="col-md-2">Major</div>
                                <div className="col-md-1">Major</div>
                                <div className="col-md-1">Stocks Sold </div>
                                <div className="col-md-1">Stocks Price</div>
                                <div className="col-md-2">Stocks Valyou </div>
                                <div className="col-md-1">6</div>
                                <div className="col-md-2">6</div>
                            </div>
                            </div>
                            <div className="row align-items-center data-secion">
                                <div className="col-md-2 text-center    ">
                                <img className="border-radius w-50 mt-2" src="https://static.wixstatic.com/media/90a05d_458062361a6b4f84b4522139a5701bf8~mv2.jpeg/v1/fill/w_95,h_95,al_c,q_90/Michael%20Jackson%20Valyou%20X%20music%20stock%20mar.webp"></img>
                                <div className="text-center">2234/3M</div>
                                <button className="btn px-1 py-0 btn-success text-small">View Profile</button>
                                </div>
                                <div className="col-md-2">1. Jackson
                                
                                </div>
                                <div className="col-md-1">Rap</div>
                                <div className="col-md-1">2,272,725</div>
                                <div className="col-md-1"><a href="#">$ 166.6</a> </div>
                                <div className="col-md-2">$ 503030034</div>
                                <div className="col-md-1"><img src={arrow} className=" arrow" ></img> </div>
                                <div className="col-md-2"><button className="btn btn-success">+4.20%</button></div>
                            </div>
                    </div>
                </li> */}
                    {this.state.listItem.map((data) =>

                        (<li>
                            <div className="card p-3 box-shadow">
                                <div className="border-bottom">
                                    <div className="row ">
                                        <div className="col-md-2">Artists</div>
                                        <div className="col-md-2">Name</div>
                                        <div className="col-md-1">Major</div>
                                        <div className="col-md-1">Stocks Sold </div>
                                        <div className="col-md-1">Stocks Price</div>
                                        <div className="col-md-2">Stocks Valyou </div>
                                        <div className="col-md-1">6</div>
                                        <div className="col-md-2">6</div>
                                    </div>
                                </div>
                                <div className="row align-items-center data-secion">
                                    <div className="col-md-2 text-center    ">
                                        <img className="border-radius w-50 mt-2" src="https://static.wixstatic.com/media/90a05d_458062361a6b4f84b4522139a5701bf8~mv2.jpeg/v1/fill/w_95,h_95,al_c,q_90/Michael%20Jackson%20Valyou%20X%20music%20stock%20mar.webp"></img>
                                        <div className="text-center">2234/3M</div>
                                        <button className="btn px-1 py-0 btn-success text-small">View Profile</button>
                                    </div>
                                    <div className="col-md-2">{data.artistName}

                                    </div>
                                    <div className="col-md-1">{data.title}</div>
                                    <div className="col-md-1">{data.category}</div>
                                    <div className="col-md-1"><a href="#">{data.stockPrice}</a> </div>
                                    <div className="col-md-2">{data.marketValue}</div>
                                    <div className="col-md-1"><img src={arrow} className=" arrow" ></img> </div>
                                    <div className="col-md-2"><button className="btn btn-success px-1 py-0">{data.__v}4.02%</button></div>
                                </div>
                            </div>
                        </li>)
                    )}
                </ul>

            </div>
        )
    }

}
export default list;
