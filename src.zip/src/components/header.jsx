import React from 'react';


function header() {
    return (
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">logo</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto ml-auto">
            <li class="nav-item ">
              <a class="nav-link" href="#">Artists </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Name</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Category</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Shares Sold / 3M</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="#">Stock Price <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Market Value</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Change % 1 Week</a>
            </li>
          </ul>
          
        </div>
      </nav>
    )

}
 export default header;
