import React from 'react';
import logo from './logo.svg';
import './App.css';
import Header from '../src/components/header.jsx';
import Tabs from '../src/components/tabs.jsx';

function App() {
  return (
    <div className="App ">
      <Header/>
      <Tabs/>
      
    </div>
  );
}

export default App;
